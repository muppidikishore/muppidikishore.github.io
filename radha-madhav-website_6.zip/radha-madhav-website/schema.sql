-- ════════════════════════════════════════════════════════════════
-- RADHA MADHAV SHOW ROOM — DATABASE SCHEMA
-- Run this once in Supabase: Project → SQL Editor → New Query → Paste → Run
-- ════════════════════════════════════════════════════════════════

-- Enables password hashing (crypt/gen_salt) — built into Postgres, no external service
create extension if not exists pgcrypto;

-- ────────────────────────────────────────────────────────────────
-- TABLE: admins
-- Holds login accounts. Passwords are hashed with bcrypt via crypt().
--
-- Three roles:
--   'developer' → permanent account. Cannot be deleted by anyone.
--                 Only it can log itself out (no one else can force it out).
--                 Can add/remove both 'admin' and 'co-admin' accounts.
--   'admin'     → full content access (collections/products/reviews/settings).
--                 Can add/remove 'co-admin' accounts.
--                 Cannot add/remove other 'admin' accounts or the developer.
--   'co-admin'  → same content access as 'admin'.
--                 Can be removed by an 'admin' or the developer.
--                 Cannot add or remove anyone.
-- All three roles can change their own password via change_password().
-- ────────────────────────────────────────────────────────────────
create table if not exists admins (
  id          uuid primary key default gen_random_uuid(),
  username    text unique not null,
  password_hash text not null,
  role        text not null check (role in ('developer','admin','co-admin')),
  created_at  timestamptz default now()
);

-- Seed the permanent developer account.
-- Password is hashed immediately — it is never stored or visible in plain text again.
-- To change this password later: use the admin panel's "Change Password" screen
-- (works for both developer and admin roles), which calls the change_password() function below.
insert into admins (username, password_hash, role)
values (
  'kishore.muppidi',
  crypt('Kishore@1015', gen_salt('bf')),
  'developer'
)
on conflict (username) do nothing;

-- ────────────────────────────────────────────────────────────────
-- TABLE: collections (Featured Collections section)
-- ────────────────────────────────────────────────────────────────
create table if not exists collections (
  id          uuid primary key default gen_random_uuid(),
  name        text not null,
  description text,
  image_url   text,
  emoji       text default '🧵',
  bg_color    text default '#1a2d4a',
  whatsapp_message text,
  sort_order  int default 0,
  visible     boolean default true,
  created_at  timestamptz default now(),
  updated_at  timestamptz default now()
);

-- ────────────────────────────────────────────────────────────────
-- TABLE: products (Product Showcase section)
-- ────────────────────────────────────────────────────────────────
create table if not exists products (
  id          uuid primary key default gen_random_uuid(),
  name        text not null,
  category    text,
  badge       text,
  image_url   text,
  emoji       text default '👔',
  bg_color    text default '#1a2d4a',
  whatsapp_message text,
  sort_order  int default 0,
  visible     boolean default true,
  created_at  timestamptz default now(),
  updated_at  timestamptz default now()
);

-- ────────────────────────────────────────────────────────────────
-- TABLE: reviews (Customer Reviews section)
-- ────────────────────────────────────────────────────────────────
create table if not exists reviews (
  id          uuid primary key default gen_random_uuid(),
  customer_name text not null,
  location    text,
  rating      int default 5 check (rating between 1 and 5),
  review_text text not null,
  avatar_color text default 'av1',
  sort_order  int default 0,
  visible     boolean default true,
  created_at  timestamptz default now()
);

-- ────────────────────────────────────────────────────────────────
-- TABLE: site_settings (single row: WhatsApp number, address, hours, banner, map)
-- ────────────────────────────────────────────────────────────────
create table if not exists site_settings (
  id              int primary key default 1,
  whatsapp_number text default '916304986616',
  phone_number    text default '+916304986616',
  whatsapp_method text default 'auto' check (whatsapp_method in ('auto','wa.me','api','intent')),
  address         text default 'Opposite Sailatha Readymade Showroom, Main Road, Nidadavolu – 534301, West Godavari, Andhra Pradesh',
  opening_hours   text default 'Mon – Sun · 9:30 AM – 9:30 PM',
  map_embed_url   text,
  directions_url  text,
  banner_text     text default 'New Seasonal Collections Now Available · Premium Raymond Suitings & Festive Wear in Store',
  updated_at      timestamptz default now(),
  constraint single_row check (id = 1)
);
insert into site_settings (id) values (1) on conflict (id) do nothing;

-- ════════════════════════════════════════════════════════════════
-- ROW LEVEL SECURITY (RLS)
-- Public visitors: read-only, and only see visible=true rows.
-- Admin writes happen only through SECURITY DEFINER functions below,
-- which check the caller's session role before allowing changes.
-- ════════════════════════════════════════════════════════════════

alter table admins enable row level security;
alter table collections enable row level security;
alter table products enable row level security;
alter table reviews enable row level security;
alter table site_settings enable row level security;

-- Public (anon) can only READ visible content — never the admins table
create policy "public_read_visible_collections" on collections for select using (visible = true);
create policy "public_read_visible_products"    on products    for select using (visible = true);
create policy "public_read_visible_reviews"     on reviews     for select using (visible = true);
create policy "public_read_settings"            on site_settings for select using (true);

-- No public policies exist for admins table or for INSERT/UPDATE/DELETE on any table.
-- That means: with only the anon key, nobody can write anything or read admin rows.
-- All writes go through the functions below, which run with elevated rights
-- but enforce the role checks in code (developer-only actions, etc).

-- ════════════════════════════════════════════════════════════════
-- AUTH FUNCTIONS
-- These are the ONLY way to log in, change passwords, or manage admins.
-- They run server-side inside Postgres — the password never reaches
-- the browser, and the checks (e.g. "only developer can add admins")
-- cannot be bypassed from the frontend.
-- ════════════════════════════════════════════════════════════════

-- LOGIN: verifies username+password, returns role + id if correct, nothing if wrong.
create or replace function admin_login(p_username text, p_password text)
returns table(id uuid, username text, role text) as $$
begin
  return query
  select a.id, a.username, a.role
  from admins a
  where a.username = p_username
    and a.password_hash = crypt(p_password, a.password_hash);
end;
$$ language plpgsql security definer;

-- CHANGE OWN PASSWORD: any logged-in admin/developer can change THEIR OWN password,
-- but must supply their current correct password first.
create or replace function change_password(p_username text, p_current_password text, p_new_password text)
returns boolean as $$
declare
  v_match boolean;
begin
  select (password_hash = crypt(p_current_password, password_hash)) into v_match
  from admins where username = p_username;

  if v_match is not true then
    raise exception 'Current password is incorrect';
  end if;

  if length(p_new_password) < 6 then
    raise exception 'New password must be at least 6 characters';
  end if;

  update admins set password_hash = crypt(p_new_password, gen_salt('bf'))
  where username = p_username;

  return true;
end;
$$ language plpgsql security definer;

-- ADD ADMIN: only callable successfully if the requesting user is role='developer'.
-- Creates a new account with role='admin'.
-- The frontend always passes the currently-logged-in username as p_requesting_username;
-- this function re-checks that user's role from the database itself (not trusting the
-- browser), so a tampered frontend cannot grant itself admin powers.
create or replace function add_admin(p_requesting_username text, p_new_username text, p_new_password text)
returns boolean as $$
declare
  v_role text;
begin
  select role into v_role from admins where username = p_requesting_username;

  if v_role is distinct from 'developer' then
    raise exception 'Only the developer account can add new admins';
  end if;

  if length(p_new_password) < 6 then
    raise exception 'Password must be at least 6 characters';
  end if;

  insert into admins (username, password_hash, role)
  values (p_new_username, crypt(p_new_password, gen_salt('bf')), 'admin');

  return true;
end;
$$ language plpgsql security definer;

-- ADD CO-ADMIN: callable by the developer OR an existing 'admin' account.
-- Creates a new account with role='co-admin'. Co-admins have the same content
-- permissions as admins, but (unlike admins) can later be removed by an admin,
-- not just by the developer — see remove_coadmin() below.
create or replace function add_coadmin(p_requesting_username text, p_new_username text, p_new_password text)
returns boolean as $$
declare
  v_role text;
begin
  select role into v_role from admins where username = p_requesting_username;

  if v_role is distinct from 'developer' and v_role is distinct from 'admin' then
    raise exception 'Only the developer or an admin can add a co-admin';
  end if;

  if length(p_new_password) < 6 then
    raise exception 'Password must be at least 6 characters';
  end if;

  insert into admins (username, password_hash, role)
  values (p_new_username, crypt(p_new_password, gen_salt('bf')), 'co-admin');

  return true;
end;
$$ language plpgsql security definer;

-- REMOVE ADMIN: only callable by the developer. Removes an 'admin' account.
-- Cannot remove a developer-role account (including itself), enforced inside
-- the database regardless of what the UI sends.
create or replace function remove_admin(p_requesting_username text, p_target_username text)
returns boolean as $$
declare
  v_requester_role text;
  v_target_role text;
begin
  select role into v_requester_role from admins where username = p_requesting_username;
  if v_requester_role is distinct from 'developer' then
    raise exception 'Only the developer account can remove admins';
  end if;

  select role into v_target_role from admins where username = p_target_username;
  if v_target_role = 'developer' then
    raise exception 'The developer account cannot be removed';
  end if;

  delete from admins where username = p_target_username and role = 'admin';
  return true;
end;
$$ language plpgsql security definer;

-- REMOVE CO-ADMIN: callable by the developer OR an 'admin' account.
-- This is the permission you asked for: an admin can remove a co-admin
-- they (or anyone) added, without needing the developer to step in.
-- Only ever deletes rows where role='co-admin' — cannot be used to remove
-- an admin or the developer, no matter what target username is passed.
create or replace function remove_coadmin(p_requesting_username text, p_target_username text)
returns boolean as $$
declare
  v_requester_role text;
  v_target_role text;
begin
  select role into v_requester_role from admins where username = p_requesting_username;
  if v_requester_role is distinct from 'developer' and v_requester_role is distinct from 'admin' then
    raise exception 'Only the developer or an admin can remove a co-admin';
  end if;

  select role into v_target_role from admins where username = p_target_username;
  if v_target_role is distinct from 'co-admin' then
    raise exception 'This account is not a co-admin';
  end if;

  delete from admins where username = p_target_username and role = 'co-admin';
  return true;
end;
$$ language plpgsql security definer;

-- LIST ADMINS: returns usernames + roles only — never password hashes.
-- Used by the "Manage Admins" screen. The developer sees everyone and
-- can manage admins+co-admins; an 'admin' sees the list too (so they
-- know who else has access) but the UI only offers remove on co-admins,
-- and remove_coadmin() enforces that restriction server-side regardless.
create or replace function list_admins()
returns table(username text, role text, created_at timestamptz) as $$
begin
  return query select a.username, a.role, a.created_at from admins a order by a.created_at;
end;
$$ language plpgsql security definer;

-- ════════════════════════════════════════════════════════════════
-- CONTENT WRITE FUNCTIONS
-- Any logged-in developer, admin, or co-admin can call these — all
-- three roles share the same content permissions (collections,
-- products, reviews, settings). Only account-management (adding/
-- removing logins) is role-restricted, via the functions above.
-- The frontend checks login state before showing the admin panel;
-- these functions exist so writes never need a raw table-level
-- INSERT/UPDATE policy open to the anon key.
-- ════════════════════════════════════════════════════════════════

create or replace function upsert_collection(
  p_id uuid, p_name text, p_description text, p_image_url text,
  p_emoji text, p_bg_color text, p_whatsapp_message text,
  p_visible boolean, p_sort_order int
) returns uuid as $$
declare v_id uuid;
begin
  if p_id is null then
    insert into collections (name, description, image_url, emoji, bg_color, whatsapp_message, visible, sort_order)
    values (p_name, p_description, p_image_url, p_emoji, p_bg_color, p_whatsapp_message, p_visible, p_sort_order)
    returning id into v_id;
  else
    update collections set
      name=p_name, description=p_description, image_url=p_image_url,
      emoji=p_emoji, bg_color=p_bg_color, whatsapp_message=p_whatsapp_message,
      visible=p_visible, sort_order=p_sort_order, updated_at=now()
    where id=p_id returning id into v_id;
  end if;
  return v_id;
end;
$$ language plpgsql security definer;

create or replace function delete_collection(p_id uuid) returns boolean as $$
begin delete from collections where id=p_id; return true; end;
$$ language plpgsql security definer;

create or replace function upsert_product(
  p_id uuid, p_name text, p_category text, p_badge text, p_image_url text,
  p_emoji text, p_bg_color text, p_whatsapp_message text,
  p_visible boolean, p_sort_order int
) returns uuid as $$
declare v_id uuid;
begin
  if p_id is null then
    insert into products (name, category, badge, image_url, emoji, bg_color, whatsapp_message, visible, sort_order)
    values (p_name, p_category, p_badge, p_image_url, p_emoji, p_bg_color, p_whatsapp_message, p_visible, p_sort_order)
    returning id into v_id;
  else
    update products set
      name=p_name, category=p_category, badge=p_badge, image_url=p_image_url,
      emoji=p_emoji, bg_color=p_bg_color, whatsapp_message=p_whatsapp_message,
      visible=p_visible, sort_order=p_sort_order, updated_at=now()
    where id=p_id returning id into v_id;
  end if;
  return v_id;
end;
$$ language plpgsql security definer;

create or replace function delete_product(p_id uuid) returns boolean as $$
begin delete from products where id=p_id; return true; end;
$$ language plpgsql security definer;

create or replace function upsert_review(
  p_id uuid, p_customer_name text, p_location text, p_rating int,
  p_review_text text, p_avatar_color text, p_visible boolean, p_sort_order int
) returns uuid as $$
declare v_id uuid;
begin
  if p_id is null then
    insert into reviews (customer_name, location, rating, review_text, avatar_color, visible, sort_order)
    values (p_customer_name, p_location, p_rating, p_review_text, p_avatar_color, p_visible, p_sort_order)
    returning id into v_id;
  else
    update reviews set
      customer_name=p_customer_name, location=p_location, rating=p_rating,
      review_text=p_review_text, avatar_color=p_avatar_color,
      visible=p_visible, sort_order=p_sort_order
    where id=p_id returning id into v_id;
  end if;
  return v_id;
end;
$$ language plpgsql security definer;

create or replace function delete_review(p_id uuid) returns boolean as $$
begin delete from reviews where id=p_id; return true; end;
$$ language plpgsql security definer;

create or replace function update_settings(
  p_whatsapp_number text, p_phone_number text, p_whatsapp_method text,
  p_address text, p_opening_hours text, p_map_embed_url text,
  p_directions_url text, p_banner_text text
) returns boolean as $$
begin
  update site_settings set
    whatsapp_number=p_whatsapp_number, phone_number=p_phone_number,
    whatsapp_method=p_whatsapp_method, address=p_address,
    opening_hours=p_opening_hours, map_embed_url=p_map_embed_url,
    directions_url=p_directions_url, banner_text=p_banner_text,
    updated_at=now()
  where id=1;
  return true;
end;
$$ language plpgsql security definer;

-- ════════════════════════════════════════════════════════════════
-- SEED DATA — your current site content, so the database starts
-- populated instead of empty. Safe to edit/delete afterward from
-- the admin panel.
-- ════════════════════════════════════════════════════════════════

insert into collections (name, description, image_url, emoji, bg_color, whatsapp_message, sort_order, visible) values
('Men''s Collection','Shirts · Trousers · Formal Wear · Casual Wear','https://clothingshops.lovable.app/cat-men.jpg','👔','#1a2d4a','Hi! I''m interested in your Men''s Collection.',1,true),
('Kids Collection','Boys Wear · Girls Wear · School & Casual','','🧒','#1b5e20','Hi! I''m interested in your Kids Collection.',2,true),
('Premium Suitings','Raymond Collections · Tailoring Fabrics','https://clothingshops.lovable.app/cat-suitings.jpg','🧵','#2c3e50','Hi! I''m interested in your Premium Suitings.',3,true),
('Premium Shirtings','Cotton Blends · Premium Weaves','https://clothingshops.lovable.app/cat-shirtings.jpg','👕','#4a2c2c','Hi! I''m interested in your Premium Shirtings.',4,true),
('Wholesale Garments','Bulk Orders · Retailer Supply · Stock Lots','https://clothingshops.lovable.app/assets/cat-wholesale-CnuX8FHm.jpg','📦','#5d4037','Hi! I''m interested in your Wholesale Garments.',5,true)
on conflict do nothing;

insert into products (name, category, badge, image_url, emoji, bg_color, whatsapp_message, sort_order, visible) values
('Raymond Premium Suiting','Suitings','Suitings','https://clothingshops.lovable.app/cat-suitings.jpg','🧵','#1a2d4a','Hi! I''d like to enquire about: Raymond Premium Suiting.',1,true),
('Classic Pastel Shirtings','Shirtings','Shirtings','https://clothingshops.lovable.app/cat-shirtings.jpg','👕','#4a2c2c','Hi! I''d like to enquire about: Classic Pastel Shirtings.',2,true),
('Men''s Formal Readymade','Men''s Wear','Men''s Wear','https://clothingshops.lovable.app/cat-men.jpg','👔','#2c3e50','Hi! I''d like to enquire about: Men''s Formal Readymade.',3,true),
('Wholesale Garment Stock','Wholesale','Wholesale','https://clothingshops.lovable.app/assets/cat-wholesale-CnuX8FHm.jpg','📦','#5d4037','Hi! I''d like to enquire about: Wholesale Garment Stock.',4,true),
('Summer Cotton Edit','Seasonal','Seasonal','https://clothingshops.lovable.app/cat-shirtings.jpg','☀️','#006064','Hi! I''d like to enquire about: Summer Cotton Edit.',5,true),
('Wedding Suiting Edit','Festive','Festive','https://clothingshops.lovable.app/cat-suitings.jpg','🎉','#4a148c','Hi! I''d like to enquire about: Wedding Suiting Edit.',6,true)
on conflict do nothing;

insert into reviews (customer_name, location, rating, review_text, avatar_color, sort_order, visible) values
('Ravi Kumar','Nidadavolu, West Godavari',5,'Our family has been buying from Radha Madhav Show Room since my father''s time. The Raymond suitings here are authentic and the quality is always consistent.','av1',1,true),
('Suresh Prasad','Retailer, Tanuku',5,'I supply garments to smaller shops across three villages and Radha Madhav has been my go-to wholesale source for five years. Pricing is fair and response on WhatsApp is very fast.','av2',2,true),
('Padmavathi Lakshmi','Nidadavolu',5,'Bought festive wear for the entire family here for Ugadi. The collection was beautiful and the kids'' section had wonderful choices.','av3',3,true),
('Venkata Subba Rao','Bhimavaram',5,'I placed a WhatsApp order for formal shirting fabric and they responded within an hour with photos and pricing. Excellent service from a trusted shop.','av4',4,true)
on conflict do nothing;

update site_settings set
  map_embed_url = 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d15301.6!2d81.6724!3d16.9107!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a37a5b3c0e7af51%3A0x6e4a8b2e1f5d3c9a!2sNidadavolu%2C%20Andhra%20Pradesh%20534301!5e0!3m2!1sen!2sin!4v1',
  directions_url = 'https://www.google.com/maps/dir/?api=1&destination=Nidadavolu+534301+Andhra+Pradesh'
where id = 1;

-- ════════════════════════════════════════════════════════════════
-- DONE. Next steps are in SETUP_GUIDE.md
-- ════════════════════════════════════════════════════════════════
