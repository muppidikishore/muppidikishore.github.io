// ════════════════════════════════════════════════════════════════
// SUPABASE CONNECTION CONFIG
// ════════════════════════════════════════════════════════════════
// Paste your two values from Supabase here:
// Project Settings → API → Project URL, and the "anon / public" key
// (NOT the service_role key — that one must never go in frontend code)
//
// This anon key is SAFE to be public / visible in browser source.
// It only allows what your RLS policies in schema.sql permit:
// public read of visible content, and calling the security-definer
// functions (which enforce their own role checks server-side).
// ════════════════════════════════════════════════════════════════

const SUPABASE_URL = 'PASTE_YOUR_PROJECT_URL_HERE';
const SUPABASE_ANON_KEY = 'PASTE_YOUR_ANON_KEY_HERE';

const supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
