# Radha Madhav Show Room — Setup Guide

This package gives you a real website with a real, securely-built admin panel.
Follow the steps in order — total time is about 10–15 minutes.

---

## 1. What's in this folder

| File | Purpose |
|---|---|
| `schema.sql` | Database setup script. Run this once inside Supabase. |
| `config.js` | Where you paste your two Supabase keys. |
| `index.html` | The full website — storefront **and** admin panel in one file. |

The admin panel is built into `index.html` itself, hidden until you open it (see "Logging in" below). There's no separate admin file or URL to remember — it's the same page, the same address, just a hidden section.

---

## 2. Create your free Supabase project (~3 minutes)

1. Go to **https://supabase.com** → Sign up (free, no credit card needed)
2. Click **New Project**
   - Name: anything, e.g. `radha-madhav-showroom`
   - Database password: choose a strong one and **save it somewhere safe** (you won't need it day-to-day, but keep it)
   - Region: pick **Singapore** (closest to India)
3. Wait ~2 minutes while it provisions

---

## 3. Run the database setup (~1 minute)

1. In your new Supabase project, click **SQL Editor** in the left sidebar
2. Click **New Query**
3. Open `schema.sql` from this folder, copy **all** of it, paste into the editor
4. Click **Run** (bottom right)
5. You should see "Success. No rows returned" — that's correct, it means all tables were created

This single script creates every table, every security rule, and seeds your developer login (`kishore.muppidi`) with a properly hashed password — the plain password is never stored anywhere after this point, including in this file.

---

## 4. Connect your site to the database (~2 minutes)

1. In Supabase, go to **Project Settings** (gear icon) → **API**
2. Copy two values:
   - **Project URL** — looks like `https://abcdefgh.supabase.co`
   - **anon / public key** — a long string starting with `eyJ...`

   ⚠️ Do **not** copy the `service_role` key — that one must never appear in a browser-facing file. The `anon` key is the only one this project needs, and it's safe to be public.

3. Open `config.js` in this folder and replace the two placeholder lines:

```js
const SUPABASE_URL = 'https://abcdefgh.supabase.co';        // ← your Project URL
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6...'; // ← your anon key
```

Save the file.

---

## 5. Deploy the site

Any static host works. Easiest free option:

1. Go to **https://app.netlify.com/drop**
2. Drag this whole folder onto the page
3. You'll get a live URL like `https://random-name-123.netlify.app`
4. (Optional) Connect your own domain later in Netlify's settings

Your site is now live at that URL, and the admin panel is at `https://your-site.netlify.app/admin.html`.

---

## 6. Log in for the first time

The admin panel is hidden inside `index.html` — there are two ways to open it:

- Go to **`your-site.com/#admin`** directly, or
- Scroll to the bottom of the site and click the small **"Admin"** link in the footer

Either one reveals the same login form. Sign in with:

- **Username:** `kishore.muppidi`
- **Password:** the one you sent me

**First thing to do:** go to **My Password** in the sidebar and change it to something only you know. The password you originally gave me was used once to seed the database — change it now so it's truly yours alone.

Clicking **"👁 View Site"** or **"Back to website"** anywhere in the panel closes it and returns you to the normal storefront view — nothing reloads, it's instant.

---

## How the security actually works

This matters, so here's the plain explanation:

- Your password is never stored as text anywhere — not in this code, not in the database. Supabase (via Postgres's `crypt()` function) stores a one-way **hash**. Even someone with full database access cannot read your password back out, only verify a guess against it.
- Logging in calls a database function (`admin_login`) that checks the hash **on the server**. The browser never sees any stored password, including other people's.
- Every privileged action — adding an admin, removing an admin, changing settings — is implemented as a database function that **re-checks your role from the database itself**, not from anything sent by the browser. Someone editing the page's JavaScript in their browser console cannot grant themselves admin rights, because the actual permission check happens inside Postgres, which they don't control.
- The developer account (`kishore.muppidi`) is protected at the database level: the `remove_admin` function explicitly refuses to delete any account with `role = 'developer'`, no matter who calls it or how.
- Regular site visitors only get **read** access to content marked visible — they cannot reach the admin functions at all; there's no code path for it.

The one thing to genuinely keep safe going forward: **your password itself.** No system design protects you if the password is weak or shared. Use a real password manager if you can.

---

## Using the admin panel — quick reference

| Task | Where |
|---|---|
| Show/hide a collection or product | Collections / Products tab → "Show"/"Hide" button |
| Add a new collection or product | Same tabs → "➕ Add" button, top right |
| Edit existing content | "Edit" button on any row |
| Add/hide customer reviews | Reviews tab |
| Change WhatsApp number | WhatsApp tab |
| Fix "WhatsApp blocked" complaints | WhatsApp tab → change **Link Method** to "Auto" (this is already the default, but if a specific device still has trouble, "api.whatsapp.com only" is the next thing to try) |
| Update showroom address / hours / map | Contact & Visit tab |
| Change the top banner text | Contact & Visit tab |
| Change your own password | My Password tab (any role can do this for themselves) |
| Add a new **admin** login | Manage Admins tab — **developer account only** |
| Add a new **co-admin** login | Manage Admins tab — **developer or admin** |
| Remove an **admin** | Manage Admins tab — **developer account only** |
| Remove a **co-admin** | Manage Admins tab — **developer or admin** |

### The three account types

| Role | Site content access | Can add | Can remove | Can be removed by |
|---|---|---|---|---|
| **Developer** | Full | Admins, co-admins | Admins, co-admins | Nobody — permanent |
| **Admin** | Full | Co-admins only | Co-admins only | Developer |
| **Co-admin** | Full | Nobody | Nobody | Developer or any admin |

All three roles see and edit the same site content (collections, products, reviews, settings) — the only difference between them is who can manage *other logins*.

---

## About the "WhatsApp blocked" issue

This is almost never actually an API block — WhatsApp doesn't operate a blockable "API" for `wa.me` links; it's a regular link. The real causes are usually:

1. **WhatsApp isn't installed** on the visitor's device (rare, but happens on desktop browsers)
2. **A popup blocker** intercepted the new tab — the site's "Auto" method already detects this and retries automatically with a different link format
3. **A corporate, school, or hotel network firewall** blocking `wa.me` specifically — switching to "api.whatsapp.com only" in the WhatsApp tab often works around this, since it's a different domain
4. The visitor is on **iOS Safari** with stricter popup rules — same fix, try the alternate method

If a specific person says it's not working, ask what device/browser they're using, and try switching the Link Method in the WhatsApp tab to match.

---

## If something goes wrong

- **Login says "connection error"** → double check `config.js` has both values filled in correctly with no extra quotes or spaces
- **Site loads but shows "Unable to load right now"** → same check, plus confirm you ran the full `schema.sql` without errors
- **Forgot your password and you're the developer** → go into Supabase → SQL Editor → run:
  ```sql
  update admins set password_hash = crypt('YourNewPassword123', gen_salt('bf'))
  where username = 'kishore.muppidi';
  ```
- **An admin forgot their password** → as the developer, you can run the same query with their username, or simply remove them and re-add them with a new password from the Manage Admins screen
